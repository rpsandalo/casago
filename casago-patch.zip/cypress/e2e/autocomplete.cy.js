
describe('Autocomplete Cidades', () => {
  it('Sugere cidades corretamente', () => {
    cy.visit('/');
    cy.get('input[aria-label="Cidade"]').type('Sao Pa');
    cy.get('datalist#cities, ul.autocomplete-list').should('exist');
  });
});
