
describe('Publicar Imóvel', () => {
  it('Imóvel aparece na listagem', () => {
    cy.visit('/publish');
    cy.get('input[name="title"]').type('Teste QA CasaGo');
    cy.get('button').contains('Publicar').click();
    cy.visit('/');
    cy.contains('Teste QA CasaGo').should('exist');
  });
});
