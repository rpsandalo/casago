
describe('Galeria rolagem', () => {
  it('Fotos rolam junto com o texto', () => {
    cy.visit('/property/1');
    cy.get('.gallery img').first().should('be.visible');
    cy.scrollTo('bottom');
    cy.get('.details').should('be.visible');
    cy.get('.gallery').should('not.have.css','position','fixed');
  });
});
