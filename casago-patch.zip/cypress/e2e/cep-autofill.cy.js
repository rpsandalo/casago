
describe('CEP Autofill', () => {
  it('Preenche endereço automaticamente', () => {
    cy.visit('/publish');
    cy.get('#cep').type('01001-000').blur();
    cy.get('#street').should('not.have.value','');
    cy.get('#city').should('contain','São Paulo');
  });
});
