
describe('Painel Resumo Datas', () => {
  it('Mostra painel após selecionar datas', () => {
    cy.visit('/');
    cy.get('#checkin').type('2025-10-10');
    cy.get('#checkout').type('2025-10-12');
    cy.get('#dates-summary').should('be.visible').and('contain','2025-10-10');
  });
});
