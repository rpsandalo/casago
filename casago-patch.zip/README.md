
# Casago Patch - GitHub Ready

## Estrutura
- data/cities-br.json -> lista completa de cidades
- css/gallery-fix.css -> corrige rolagem de imagens
- Cypress -> testes E2E
- pdf -> relatórios PT e EN
- HTML -> inserir diretamente os patches de JS embutidos

## Patches JS (embutir no HTML)
- Autocomplete de cidades
- Painel resumo de datas
- CEP + preenchimento automático
- Publicar imóvel (localStorage)
- Correção de galeria

## Instruções
1. Subir o HTML atualizado com os patches embutidos.
2. Copiar CSS para o projeto.
3. Rodar Cypress para validar todos os fluxos.
